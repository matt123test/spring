package com.example.springboot.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.AbstractMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RedisController {
    @Autowired
    @Qualifier("redisTemplate")
    private RedisTemplate<String, String> template;
    @PostMapping("/key")
    @ResponseStatus(HttpStatus.CREATED)
    public Map.Entry<String, String> setKey(@RequestBody Map.Entry<String, String> kv) {
        template.opsForValue().set(kv.getKey(), kv.getValue());

        return kv;
    }
    @GetMapping("/key/{key}")
    public Map.Entry<String, String> getKey(@PathVariable("key") String key) {
        String value = template.opsForValue().get(key);

        if (value == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "key not found");
        }

        return new AbstractMap.SimpleEntry<String, String>(key, value);
    }
}
