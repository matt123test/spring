package com.example.springboot.redis;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;

@Configuration
public class RedisClusterConfig {
    @Autowired
    RedisClusterConfigurationProperties redisClusterConfigurationProperties;
    @Value("${spring.redis.ssl:false}")
    private boolean ssl;
    @Value("${spring.redis.password:#{null}}")
    private String password;
    @Value("${spring.redis.cluster.max-redirects:5}")
    private int maxRedirects;
    @Value("${spring.redis.jedis.pool.max-idle}")
    private int maxIdle;
    @Value("${spring.redis.jedis.pool.min-idle}")
    private int minIdle;
    @Value("${spring.redis.jedis.pool.max-active}")
    private int maxActive;
    @Value("${spring.redis.jedis.pool.max-wait}")
    private long maxWait;

    // add destroyMethod = "destroy" to avoid Redis connection is closed before bean closure.
    // https://zhuanlan.zhihu.com/p/440034430
    @Bean(destroyMethod = "destroy")
    JedisConnectionFactory redisConnectionFactory() {
        RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration(
                redisClusterConfigurationProperties.getNodes()
        );
        System.out.println("Cluster Nodes:" + redisClusterConfiguration.getClusterNodes());
        if (password != null) {
            redisClusterConfiguration.setPassword(password);
        }
        redisClusterConfiguration.setMaxRedirects(maxRedirects);
        JedisClientConfiguration.JedisClientConfigurationBuilder
                jedisClientConfigurationBuilder = JedisClientConfiguration.builder();
        if (ssl) {
            jedisClientConfigurationBuilder.useSsl();
        }
        GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        genericObjectPoolConfig.setMaxIdle(maxIdle);
        genericObjectPoolConfig.setMinIdle(minIdle);
        genericObjectPoolConfig.setMaxTotal(maxActive);
        genericObjectPoolConfig.setTimeBetweenEvictionRunsMillis(3000);
        jedisClientConfigurationBuilder.usePooling().poolConfig(genericObjectPoolConfig);
        JedisClientConfiguration clientConfiguration = jedisClientConfigurationBuilder.build();
        return new JedisConnectionFactory(redisClusterConfiguration, clientConfiguration);
    }

    @Bean
    RedisTemplate<String, String> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, String> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new StringRedisSerializer());
        return template;
    }
}
